---
note_type: Project
PCode: "[[P1010]]"
project: "[[02 Projects/P1010/In Vitro Assay/Expression/Expression.md|Expression]]"
parent_project: "[[02 Projects/P1010/In Vitro Assay/In Vitro Assay.md|In Vitro Assay]]"
people: 
topics: 
created: 2023-12-25T11:52:35-06:00
created_by: BMohr
---
# Notebook


# Documents
## Related Notes - Still need to add related notes

## Files
```dataview
TABLE file.ext as "File Extension", file.ctime as Created
FROM "02 Projects/P1010/In Vitro Assay/Expression"
WHERE file !=this.file
SORT file.ctime DESC
```