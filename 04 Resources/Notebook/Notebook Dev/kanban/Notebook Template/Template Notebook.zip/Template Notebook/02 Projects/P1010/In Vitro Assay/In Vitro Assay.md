---
note_type: Project
PCode: "[[P1010]]"
project: "[[02 Projects/P1010/In Vitro Assay/In Vitro Assay.md|In Vitro Assay]]"
parent_project: "[[02 Projects/P1010/P1010.md|P1010]]"
people: 
topics: 
created: 2023-12-25T11:51:14-06:00
created_by: BMohr
---
# Notebook
## 2023-12-25-NADH Spectroscopy
 ![[2023-12-25-NADH Spectroscopy]]
## 2023-12-25-Pyruvate Kinase
 ![[2023-12-25-Pyruvate Kinase]]
## 2023-12-25-ATP Cycling
 ![[2023-12-25-ATP Cycling]]
## Expression
 ![[02 Projects/P1010/In Vitro Assay/Expression/Expression.md# Notebook|Expression]]
## 2023-12-25-Combos II
 ![[2023-12-25-Combos II]]
## 2023-12-25-Combos I
 ![[2023-12-25-Combos I]]
## 2023-12-25-Range Finding I
 ![[2023-12-25-Range Finding I]]
## 2023-12-25-Controls I
 ![[2023-12-25-Controls I]]


# Documents
## Related Notes - Still need to add related notes

## Files
```dataview
TABLE file.ext as "File Extension", file.ctime as Created
FROM "02 Projects/P1010/In Vitro Assay"
WHERE file !=this.file
SORT file.ctime DESC
```