---
kanban-plugin: basic
note_type: Kanban
PCode: "[[02 Projects/P1010/P1010.md|P1010]]"
project: "[[02 Projects/P1010/In Vitro Assay/Expression/Expression.md|Expression]]"
created: 2023-12-25T11:52:36-06:00
created_by: BMohr
---
## To-Do

## Doing

## Done

## Archive


%% kanban:settings
```
{"kanban-plugin":"basic", "new-note-folder":"02 Projects/P1010/In Vitro Assay/Expression/experiments", "new-note-template":"04 Resources/Notebook/Note Templates/32 Notebook Card Template.md"}
```
%%