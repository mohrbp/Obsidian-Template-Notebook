---
note_type: atomic
PCode: 
project: 
people: 
topics: 
created: 2023-12-22T21:45:09-06:00
created_by: BMohr
total_tasks: 0
completed_tasks: 0
incomplete_tasks: 0
---
# Content

`$= dv.current().file.tasks`

# Action Items
- [ ] Another One [DXP](02%20Projects/P1000/DXP/DXP.md) ⌛ 
