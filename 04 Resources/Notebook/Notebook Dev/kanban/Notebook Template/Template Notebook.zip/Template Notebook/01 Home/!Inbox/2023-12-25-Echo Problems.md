---
note_type: atomic
PCode: 
project: 
people: 
topics: 
created: 2023-12-25T11:55:11-06:00
created_by: BMohr
total_tasks: 0
completed_tasks: 0
incomplete_tasks: 0
---
# Notes
# Tasks
- [ ] Power Cycle ⌛ 2023-12-25 
