---
kanban-plugin: basic
template_type: All
note_type: Kanban Template
---
## To-Do

## Doing

## Done

## Archive


%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%