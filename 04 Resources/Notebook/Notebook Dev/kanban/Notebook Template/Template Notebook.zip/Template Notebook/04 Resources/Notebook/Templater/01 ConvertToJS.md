<%* tp.user.sync().jsFromMarkdown({js: "04 Resources/Notebook/Scripts", md: "04 Resources/Notebook/ScriptsMD"}) %>
