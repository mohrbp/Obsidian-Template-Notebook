<%* date = await tp.user.datePicker(tp) -%>
<% date %>