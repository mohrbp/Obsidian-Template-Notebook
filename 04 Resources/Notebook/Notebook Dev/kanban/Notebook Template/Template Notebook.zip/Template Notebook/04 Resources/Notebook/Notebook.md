# Welcome to Obsidian


# Notebook Overview

## Main Workflow
